package poly.com.controller;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.model.country;

@WebServlet("/bai 1")
public class bai1servlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		List<country> list = List.of(new country("vn", "vietnam"), new country("us", "usa"),
				new country("cn", "china"));
		req.setAttribute("countries", list);
		req.getRequestDispatcher("bai1.jsp").forward(req, resp);
	}
}
