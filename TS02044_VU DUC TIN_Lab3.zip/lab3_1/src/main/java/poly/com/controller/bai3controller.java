package poly.com.controller;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet({ "/bai 3", "/bai 4" })
public class bai3controller extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String chon = req.getRequestURI();

		if (chon.contains("/bai 3")) {

			Map<String, Object> map = new HashMap<>();
			map.put("name", "ip 17");
			map.put("price", 20000000);
			map.put("date", new Date());

			req.setAttribute("item", map);
			req.getRequestDispatcher("bai3.jsp").forward(req, resp);

		} else {

			Map<String, Object> map = new HashMap<>();
			map.put("title", "tieu de ban tin");
			map.put("content", "noi dung ban tin thuong rat dai");

			req.setAttribute("item", map);
			req.getRequestDispatcher("bai4.jsp").forward(req, resp);
		}
	}
}

