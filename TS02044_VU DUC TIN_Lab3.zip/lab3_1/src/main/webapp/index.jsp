<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>trang menu</title>
</head>
<body>
<a href="bai 1">bài 1</a> ||
<a href="bai 2">bài 2</a> ||
<a href="bai 3">bài 3</a> ||
<a href="bai 4">bài 4</a> ||

</body>
</html>