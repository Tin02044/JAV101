<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<html>
<head>
<meta charset="UTF-8">
<title>trang bai 4</title>
</head>
<body>
	<a href="bai 3">bài 3</a> ||
	<a href="bai 4">bài 4</a> ||
	<hr>

	<ul>
		<li>Title: ${fn:toUpperCase(item.title)}</li>
		<li>
			Content:
			<c:choose>
				<c:when test="${fn:length(item.content) > 100}">
					${fn:substring(item.content, 0, 100)}...
				</c:when>
				<c:otherwise>
					${item.content}
				</c:otherwise>
			</c:choose>
		</li>
	</ul>
</body>
</html>
