<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<%@taglib uri="http://java.sun.com/jstl/core_rt" prefix="c"%>
<html>
<head>
<meta charset="UTF-8">
<title>trang bai 2</title>
</head>
<body>
	<a href="bai 1">bài 1</a> ||
	<a href="bai 2">bài 2</a> ||
	<a href="bai 3">bài 3</a> ||
	<a href="bai 4">bài 4</a> ||
	<hr />
	<table border="1">
		<thead>
			<tr>
				<th>No.</th>
				<th>Id</th>
				<th>Name</th>
			</tr>
		</thead>
		<tbody>
			<c:forEach var="ct" items="${countries}" varStatus="vs">
				<tr>
					<td>${vs.count}</td>
					<td>${ct.id}</td>
					<td>${ct.name}</td>
				</tr>
			</c:forEach>
		</tbody>
	</table>

</body>
</html>