<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<%@taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<html>
<head>
<meta charset="UTF-8">
<title>trang bai 1</title>
</head>
<body>
<a href="bai 1">bài 1</a> ||
<a href="bai 2">bài 2</a> ||
<a href="bai 3">bài 3</a> ||
<a href="bai 4">bài 4</a> ||
<hr/>
<select name= "country">
<c:forEach var= "ct" items="${countries }">
   <option value="${ct.id}">${ct.name }</option>

</c:forEach>

</select>
</body>
</html>