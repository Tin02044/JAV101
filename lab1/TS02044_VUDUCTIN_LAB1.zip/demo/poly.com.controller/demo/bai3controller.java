package demo;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/bai3/*") // thêm /* để có thể test PathInfo
public class bai3controller extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Thiết lập kiểu hiển thị
        resp.setContentType("text/html;charset=UTF-8");

        PrintWriter out = resp.getWriter();

        out.println("<html><body>");
        out.println("<h2>Thông tin URL</h2>");
        out.println("<ul>");
        out.println("<li><b>URL:</b> " + req.getRequestURL() + "</li>");
        out.println("<li><b>URI:</b> " + req.getRequestURI() + "</li>");
        out.println("<li><b>Query String:</b> " + req.getQueryString() + "</li>");
        out.println("<li><b>Servlet Path:</b> " + req.getServletPath() + "</li>");
        out.println("<li><b>Context Path:</b> " + req.getContextPath() + "</li>");
        out.println("<li><b>Path Info:</b> " + req.getPathInfo() + "</li>");
        out.println("<li><b>Method:</b> " + req.getMethod() + "</li>");
        out.println("</ul>");
        out.println("</body></html>");
    }
}
