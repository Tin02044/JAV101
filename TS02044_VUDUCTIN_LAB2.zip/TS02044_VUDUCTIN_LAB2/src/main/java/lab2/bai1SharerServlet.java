package lab2;

	import jakarta.servlet.*;
	import jakarta.servlet.annotation.WebServlet;
	import jakarta.servlet.http.*;
	import java.io.IOException;

	@WebServlet("/bai1sharerServlet")
	public class bai1SharerServlet extends HttpServlet {
	    @Override
	    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
	            throws ServletException, IOException {

	        // Gửi dữ liệu sang JSP
	        req.setAttribute("message", "Hello from SharerServlet!");
	        req.getRequestDispatcher("/page.jsp").forward(req, resp);
	    }
	}


