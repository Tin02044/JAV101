package lab2;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/bai2userServlet")
public class bai2UserServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setAttribute("message", "Welcome to FPT Polytechnic");

        Map<String, Object> user = new HashMap<>();
        user.put("fullname", "Vũ Đức Tín");
        user.put("gender", "Male");
        user.put("country", "Việt Nam");

        req.setAttribute("user", user);
        req.getRequestDispatcher("/page.jsp").forward(req, resp);
    }
}
